require('./bootstrap');
require('./leaflet-map');

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
