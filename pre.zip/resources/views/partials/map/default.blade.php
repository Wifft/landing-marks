<section class="w-full">
    <div id="map" class="h-full"></div>
</section>
