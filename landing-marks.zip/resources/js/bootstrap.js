import * as leaflet from 'leaflet';

require('leaflet-draw/dist/leaflet.draw');

const L = leaflet;
