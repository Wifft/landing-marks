<script>
    const user = <?php echo json_encode($user); ?>;
    const mapId = <?php echo e($map->id); ?>;
    const saveMarkUri = "<?php echo e(route('api.maps.storeUserMark')); ?>";
    const deleteMarkUri = "<?php echo e(route('api.maps.deleteUserMark')); ?>";
    const storeUserActivityUri = "<?php echo e(route('api.userActivities.store')); ?>";
    const mapUsersData = <?php echo json_encode($map->discordUsers); ?>;
</script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH A:\laragon\www\landing-marks\resources\views/partials/site/scripts.blade.php ENDPATH**/ ?>