<aside class="w-full">
    <section class="h-full bg-zinc-800">
        <h1 class="text-white text-4xl text-center p4 font-bold py-4"><?php echo e($map->title); ?></h1>
        <hr/>
        <div class="h-[785px] overflow-auto">
            <?php $__empty_1 = true; $__currentLoopData = $map->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <p class="text-white py-2 px-4">
                    <b><?php echo e(\Carbon\Carbon::parse($activity->created_at)->format('H:i:s')); ?></b>
                    <span class="text-yellow-300"><?php echo e($activity->user->nickname); ?></span>
                    <?php echo e($activity->message); ?>

                </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-white text-center">This map hasn't activity yet.</p>
            <?php endif; ?>
        </div>
        <div class="bg-black text-center pt-2">
            <?php if(is_null($user)): ?>
                <a class="btn btn-red" href="<?php echo e(route('discord.login')); ?>">
                    <i class="fab fa-discord"></i>
                    Login with Discord!
                </a>
            <?php else: ?>
                <img class="h-20 m-auto rounded-full"
                    src="<?php echo e($user->avatar); ?>"
                    alt="<?php echo e($user->nickname); ?>"
                    name="<?php echo e($user->nickname); ?>"/>
                <p class="text-white">Welcome, <?php echo e($user->nickname); ?>!</p>
            <?php endif; ?>
        </div>
    </section>
</aside>
<?php /**PATH A:\laragon\www\landing-marks\resources\views/partials/map/aside.blade.php ENDPATH**/ ?>