<section class="w-full">
    <div id="map" class="h-full"></div>
</section>
<?php /**PATH A:\laragon\www\landing-marks\resources\views/partials/map/default.blade.php ENDPATH**/ ?>